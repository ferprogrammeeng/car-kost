<footer>
  <p>&copy; 2022 Pencarian kost</p>
</footer>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDiIKIfaFR_ubQUDVDzO5D-LwY_4biVMqc&callback=initMap&v=weekly" defer></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
<!-- <script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script> -->

<script src="assets/js/script.js"></script>

</body>
</html>